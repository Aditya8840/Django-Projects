from django.apps import AppConfig


class StrucConfig(AppConfig):
    name = 'struc'
