from django.db import models
from django.contrib.auth.models import User
from datetime import datetime

from django.http import request

# Create your models here.
class Profile(models.Model):
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    profile_pic = models.ImageField(null=True, default="default.jpeg" ,blank= True, upload_to="image/")
    city = models.CharField(max_length=30)
    country = models.CharField(max_length=30)
    proffesion = models.CharField(max_length=50, default='Student at Hewett Polytechnic')
    facebook = models.CharField(max_length=100)
    github = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)

class Posts(models.Model):
    user = models.CharField(max_length=100)
    title = models.CharField(max_length=30, blank=True)
    img = models.ImageField(null=True,blank= True, upload_to="image/")
    feed = models.CharField(max_length=300, blank=True)
    date = models.DateTimeField(default=datetime.now(),editable=False)

   #def __str__(self):
    #    return str(self.user)