from django.shortcuts import render , redirect
from django.http import HttpResponse
from django.contrib.auth.models import User, auth, AnonymousUser
#from django.contrib.auth import logout
from .models import Profile, Posts
from django.contrib import messages
from datetime import date, datetime
from django.core.files.storage import FileSystemStorage
# Create your views here.
def index(request):
    if request.user.id is None:
        return render(request, 'login.html')
    elif Profile.objects.filter(user=request.user):
        return render(request, 'index.html', {'data': Profile.objects.filter(user=request.user), 'data1': Posts.objects.all()})
    else:
        return render(request, 'details.html')
    return render(request, 'index.html')

def register(request):
    if request.user.id is None:
        if request.method == 'POST':
            username = request.POST['username']
            first_name = request.POST['first_name']
            last_name = request.POST['last_name']
            email = request.POST['email']
            password = request.POST['password']
            password1 = request.POST['password1']
            if password == password1:
                if User.objects.filter(username=username):
                    messages.error(request, 'This username is alredy taken')
                    return render(request, 'register.html')

                elif User.objects.filter(email=email):
                    messages.error(request, 'This email is alredy registered')
                    return render(request, 'register.html')
                else:
                    user = User.objects.create_user(username=username , first_name=first_name , last_name=last_name, email=email , password=password)
                    user.save()
                    return render(request, 'login.html')
            else:
                messages.error(request, 'Password and Confirm password is not same')
                return render(request, 'register.html')
        else:
            return render(request , 'register.html')
    else:
        name = request.user.first_name
        messages.error(request, f'Hii {name},You are already our registered user')
        return render(request, 'index.html')
    return render(request , 'register.html')

def details(request):
    if request.user.id is None:
        return render(request, 'login.html')
    elif Profile.objects.filter(user=request.user):
        return my_profile(request)
    else:
        if request.method == 'POST':
            phone = request.POST['phone']
            img = request.FILES['profile_pic']
            fs = FileSystemStorage()
            filename = fs.save(img.name, img)
            uploaded_file_url = fs.url(filename)
            profession = request.POST['profession']
            city = request.POST['city']
            country = request.POST['country']
            facebook = request.POST['facebook']
            github = request.POST['github']
            user = request.user
            profile = Profile(phone=phone, profile_pic=img ,city=city, country=country, facebook=facebook, proffesion=profession ,github=github, user=user)
            profile.save()
            messages.success(request, f'Hii {request.user.first_name} ,Your data is Sucessfully saved')
            return index(request)
        else:
            return render(request, 'details.html')
    return render(request , 'details.html')



def login(request):
    if request.user.id is None:
        if request.method == 'POST':
            username = request.POST['username']
            password = request.POST['password']
            user = auth.authenticate(username=username , password=password)
            if user is not None:
                auth.login(request, user)
                messages.success(request, f'You are sucessfully login as {username}')
                return index(request)
            else:
                messages.error(request, 'Your given credentials are wrong')
                return render(request, 'login.html')
        else:
            return render(request, 'login.html')
    else:
        Username = request.user.username
        messages.error(request, f'You are alredy logged in as {Username}')
        return index(request)
    return render(request, 'login.html')

def my_profile(request):
    if request.user.id is None:
        return login(request)
    else:
        datas = Profile.objects.filter(user=request.user)
        a = {'data':datas}
        for i in a['data']:
            if i.city is None:
                return render(request, 'details.html')
            else:
                return render(request,'profile.html', {'data':datas})
        return render(request, 'profile.html', {'data':datas})
    return render(request, 'profile.html')
def logout(request):
    if request.user.id is None:
        return login(request)
    else:
        auth.logout(request)
        messages.success(request, f'You are sucessfully logout ')
        return render(request , 'login.html')

def posts(request):
    if request.user.id is None:
        return login(request)
    else:
        if request.method == "POST":
            user = request.user
            title = request.POST['title']
            img = request.FILES['img']
            fs = FileSystemStorage()
            filename = fs.save(img.name, img)
            uploaded_file_url = fs.url(filename)
            feed = request.POST['feed']
            posts = Posts(user=user, title=title, img=img, feed=feed, date=datetime.now())
            posts.save()
            messages.success(request, f'Hii {request.user.first_name }, Your Post is posted Sucessfully')
            return index(request)
        else:
            return render(request, 'posts.html')
    return render(request, 'posts.html')
    
    
