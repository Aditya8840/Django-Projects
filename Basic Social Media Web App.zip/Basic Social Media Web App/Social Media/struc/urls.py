from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings
urlpatterns = [
    path('', views.index , name= 'index'),
    path('register', views.register , name= 'register'),
    path('login', views.login , name= 'Login'),
    path('my_profile', views.my_profile , name= 'my_profile'),
    path('details', views.details, name= 'details'),
    path('logout', views.logout, name= 'logout'),
    path('posts', views.posts, name= 'posts')
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
